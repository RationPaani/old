// Spanish localized datepicker for bootstrap
$.fn.datepicker.defaults_es = {
    monthNames: ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
                 "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"],
    shortDayNames: ["Dom", "Lun", "Mar", "Mie", "Jue", "Vie", "Sab"],
    startOfWeek: 1
  };
