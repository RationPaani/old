  //Turkish localized datepicker for bootstrap
  $.fn.datepicker.defaults_tr= {
      monthNames: ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran",
                   "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"],
      shortDayNames: ["Pzt", "Sal", "Çar", "Per", "Cum", "Cts", "Paz"],
      startOfWeek: 1
    };
